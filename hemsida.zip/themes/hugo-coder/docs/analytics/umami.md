# Umami

```toml
[params.umami]
    siteID = "ABCDE"
    serverURL = "analytics.example.com"
```
