# Clicky

```toml
[params.clicky]
    id = "site-id"
```