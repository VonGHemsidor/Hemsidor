# Goat Counter

```toml
[params.goatCounter]
  code = "code" # You will access your account at https://[code].goatcounter.com
```
