# microanalytics.io

```toml
[params.microAnalytics]
    id = "ABCDE"
    dnt = "false" # respect DNT tracker, "true" by default
```
