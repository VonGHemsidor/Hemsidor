# Application Insights

```toml
[params.applicationInsights]
    connectionString = "connectionstring" # https://docs.microsoft.com/en-us/azure/azure-monitor/app/sdk-connection-string
```
