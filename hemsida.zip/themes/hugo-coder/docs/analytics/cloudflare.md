# Cloudflare

```toml
[params.cloudflare]
    token = "token"
```
