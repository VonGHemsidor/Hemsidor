# Google Analytics

Follow [these steps](https://gohugo.io/templates/internal/#configure-google-analytics).